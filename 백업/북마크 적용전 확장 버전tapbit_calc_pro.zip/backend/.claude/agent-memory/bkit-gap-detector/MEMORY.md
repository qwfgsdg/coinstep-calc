# Gap Detector Memory - tapbit_calc_pro

## Project Structure
- Backend: `backend/` (Express + sql.js, Starter-level architecture: api/, lib/, static/)
- Bookmarklet: `bookmarklet/sync.js` + `backend/static/sync.js` (hosted copy)
- Frontend integration: `coinstep-calc/calc.jsx` (6400+ lines) + `coinstep-calc/web-sync.js`
- Design docs: `docs/02-design/features/`
- Analysis output: `docs/03-analysis/`

## web-sync Feature (2026-03-10)
- Match rate: 93% (above 90% threshold)
- Key gaps: CORS missing PATCH method, no data retention batch jobs, innerHTML in web-sync.js
- Design used Korean language throughout
- calc.jsx is too large (>256KB) to read fully -- use offset/limit or grep

## Known Patterns
- Auth: SyncToken (`stk_` prefix) for bookmarklet, JWT Bearer for frontend
- DB: sql.js (SQLite in-process), auto-save with debounce
- CORS: configured via CORS_ORIGINS env var, custom middleware (not cors package)
- Admin: admin.html + admin.js with setup/login/CRUD flow
