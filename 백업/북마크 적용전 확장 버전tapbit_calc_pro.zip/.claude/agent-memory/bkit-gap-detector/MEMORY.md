# Gap Detector Memory - tapbit_calc_pro

## Project Structure
- Chrome extension in `extensions/` directory (not src/)
- Key files: manifest.json, background.js, inject-tapbit.js, content-tapbit.js, content-calc.js
- Design docs in `docs/02-design/features/`
- Analysis output: `docs/03-analysis/`

## Key Architectural Decisions
- UI injection moved from Tapbit (agent.tapbit.com) to Coinstep (pro.coinstep.co.kr) — approved deviation
- Summary API uses 3-hop proxy (background -> content-tapbit -> inject-tapbit MAIN world) for cookie/Origin preservation
- Data sharing between sites via chrome.storage.local (tapbitHistories key)
- content-calc.js uses innerHTML for table rendering (design specified textContent — minor security consideration)

## Analysis History
- 2026-03-09: history-pnl-fee-analysis — Match Rate 84% (92% if intentional changes counted as matches)
  - 3 missing minor features: localStorage collapse, retry button, Tapbit date defaults
  - PnL calculation: 100% match with design
  - Recommendation: update design doc to match implementation
