# Archive Index — 2026-03

| Feature | Archived | Match Rate | Documents |
|---------|----------|:----------:|-----------|
| web-sync | 2026-03-10 | 96% | plan, design, analysis, report |

## web-sync

- **Description**: Chrome 확장 없는 Web 동기화 (북마클릿 + Backend API + 프론트엔드 통합)
- **PDCA Cycle**: Plan → Design → Do → Check (96%) → Report
- **Duration**: 2026-03-10 (single session)
- **Path**: `docs/archive/2026-03/web-sync/`
