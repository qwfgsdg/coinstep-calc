# Plan: 확장 프로그램 없는 Web 동기화

> Plan Plus (Brainstorming-Enhanced) | 생성일: 2026-03-10

---

## Executive Summary

| 항목 | 내용 |
|------|------|
| Feature | web-sync (확장 프로그램 제거, 웹 기반 동기화) |
| 생성일 | 2026-03-10 |
| 예상 범위 | 북마클릿 스크립트 + Backend API + Coinstep 프론트엔드 개편 |

| 관점 | 내용 |
|------|------|
| **Problem** | Chrome 확장 프로그램 설치가 번거로워 수십명 규모 사용자 온보딩이 어려움. 확장은 Chrome에서만 동작하고 모바일/다른 브라우저에서 사용 불가 |
| **Solution** | 북마클릿으로 Tapbit 페이지에서 데이터를 추출하여 Backend API로 전송. Coinstep은 Backend에서 데이터를 읽어 표시 |
| **Function UX Effect** | 북마크바에 드래그 1회로 설치 완료. Tapbit 탭에서 북마클릿 클릭 → Coinstep에서 바로 확인 |
| **Core Value** | 설치 없는 온보딩 + 모든 브라우저 지원 + API 호출 IP 분산으로 서버 부담 제거 |

---

## 1. User Intent Discovery

### Core Problem
- Chrome 확장 프로그램 설치가 번거로움 (개발자 모드, 압축 풀기 등)
- 수십명의 에이전트가 각자 Tapbit 계정으로 Coinstep을 사용해야 함
- 한 서버에서 Tapbit API를 과다 호출하면 IP 차단 위험

### Target Users
- Tapbit 에이전트 (수십명), 각자 Tapbit 계정 보유
- IT 비전문가 포함 → 설치 과정 최소화 필수

### Success Criteria
1. 확장 프로그램 설치 없이 Tapbit 데이터를 Coinstep에서 확인 가능
2. Tapbit API 호출은 각 사용자 브라우저에서 발생 (IP 분산)
3. Backend는 데이터 저장/조회만 담당 (Tapbit API 직접 호출 없음)
4. 기존 기능 유지: 포지션, 계좌, 거래내역 PnL%, 수수료 조회

### Constraints
- Tapbit API는 per-request auth 서명 사용 (외부 서버에서 호출 불가)
- Tapbit API에 CORS 제한 있음 (coinstep.co.kr에서 직접 호출 불가)
- 북마클릿은 Tapbit 페이지 컨텍스트에서 실행되므로 위 제약 우회 가능

---

## 2. Alternatives Explored

### Approach A: 북마클릿 + Backend — 선택됨
- **장점**: 확장 설치 없음, 모든 브라우저 지원, API 호출 IP 분산, 기존 dva dispatch 로직 재사용 가능
- **단점**: 수동 클릭 필요 (자동 갱신 불가), CSP에 의해 외부 스크립트 로딩 차단 가능성
- **선택 이유**: 사용자의 핵심 요구(설치 번거로움 제거 + IP 분산)를 가장 잘 충족

### Approach B: Auth 리버스엔지니어링 + Server Proxy
- **장점**: 완전 자동화 가능, 사용자 추가 액션 불필요
- **단점**: Tapbit 업데이트 시 깨짐, 모든 API가 서버 IP에서 발생, TOS 위반 가능성
- **제외 이유**: 유지보수 부담 + IP 분산 불가

### Approach C: 미니 확장 + Web Backend
- **장점**: 자동 갱신 가능, 안정적
- **단점**: 여전히 확장 설치 필요 → 핵심 목적 불부합
- **제외 이유**: "설치 번거로움 제거"라는 핵심 요구 미충족

---

## 3. YAGNI Review

### v1 포함 (필수)
- [x] 북마클릿 스크립트 (Tapbit 페이지에서 데이터 추출 + Backend 전송)
- [x] Backend API (데이터 수신/저장/조회)
- [x] Coinstep 프론트엔드 개편 (chrome.storage → Backend API)
- [x] 사용자 식별 (Tapbit maskId/profile 기반)
- [x] 포지션 + 계좌 + 거래내역 + 수수료 조회 기능 유지

### Out of Scope (v1에서 제외)
- 자동 갱신 (30초 간격) → 북마클릿은 수동 클릭
- 사용자 로그인/회원가입 시스템 → maskId로 식별 (추후 추가 가능)
- 실시간 WebSocket 업데이트
- 거래내역 CSV 내보내기
- 차트/그래프 시각화

---

## 4. Technical Design

### 4.1 Architecture Overview

```
[사용자 브라우저 — Tapbit 탭]
  ↓ 북마클릿 클릭
[sync.js] (Tapbit 페이지 컨텍스트에서 실행)
  - window.g_app._store 접근 (dva store)
  - lists/filtersChange + lists/pageChange dispatch
  - fetch intercept → positions, accounts, histories 수집
  ↓ POST (CORS: Coinstep 서버가 허용)
[Coinstep Backend API]
  - POST /api/sync — 데이터 수신 + 저장
  - GET  /api/data — 데이터 조회
  - POST /api/fee  — 수수료 계산 (저장된 histories 기반)
  ↓ REST API
[Coinstep Frontend (calc.jsx)]
  - chrome.storage 제거 → fetch('/api/data') 사용
  - 기존 UI 유지
```

### 4.2 북마클릿 스크립트 (sync.js)

**호스팅**: GitHub Pages 또는 CDN (jsdelivr)

**북마클릿 로더**:
```javascript
javascript:(function(){var s=document.createElement('script');
s.src='https://cdn.jsdelivr.net/gh/{user}/{repo}@main/sync.js?t='+Date.now();
document.head.appendChild(s)})()
```

**CSP 차단 시 대안**:
- 북마클릿에 전체 코드 인라인 (minify + 압축)
- 또는 콘솔 붙여넣기 가이드 (README에 "복사" 버튼)

**sync.js 핵심 로직** (기존 확장 코드 재사용):
```
1. window.g_app._store 존재 확인
2. dva store에서 현재 데이터 읽기:
   - lists.positions → 포지션 목록
   - lists.accounts → 계좌 목록
3. histories 수집 (페이지네이션):
   - lists/filtersChange dispatch (날짜 범위)
   - __TAPBIT_HISTORIES__ 메시지 수신
   - list.length === 100이면 lists/pageChange로 다음 페이지
   - 모든 페이지 누적
4. profile 수집:
   - store state에서 maskId, remarkName 추출
5. Backend로 전송:
   - POST https://api.coinstep.co.kr/api/sync
   - Body: { profile, positions, accounts, histories }
6. 완료 알림 (toast UI)
```

### 4.3 Backend API

**스택 후보**:
| 옵션 | 장점 | 단점 |
|------|------|------|
| Vercel Serverless + Supabase | 프론트와 같은 플랫폼, 무료 티어 | DB 제한 (500MB) |
| Vercel Serverless + MongoDB Atlas | 무료 512MB, JSON 친화적 | 별도 관리 |
| 독립 Node.js + SQLite | 완전 자체 관리, 비용 없음 | 서버 직접 운영 |

**API 엔드포인트**:

```
POST /api/sync
  - Request: { profile: {maskId, remarkName}, positions: [...], accounts: [...], histories: [...] }
  - 사용자 식별: profile.maskId
  - 저장: DB에 upsert (maskId 기준)
  - Response: { ok: true, recordCount: N }

GET /api/data?maskId={id}
  - Response: { positions, accounts, histories, lastSync }
  - Coinstep 프론트에서 호출

GET /api/data/all
  - Response: 전체 사용자 목록 + 최신 동기화 시간
  - 관리자용 (에이전트 전체 현황)

POST /api/fee
  - Request: { maskId, startTime, endTime }
  - Backend에서 저장된 histories 필터링 → tradeFee 합산
  - Response: { totalFee, recordCount, traders }
```

**인증 (최소한)**:
- v1: API 키 기반 (단순 토큰, 북마클릿에 내장)
- v2: Coinstep 자체 로그인 시스템 (추후)

### 4.4 Coinstep 프론트엔드 변경

```
변경 전 (chrome.storage 의존):
  chrome.storage.local.get("tapbitData") → 데이터 표시
  chrome.storage.onChanged → 실시간 업데이트

변경 후 (Backend API 의존):
  fetch('/api/data?maskId=xxx') → 데이터 표시
  "새로고침" 버튼 클릭 → 다시 fetch

기존 기능 유지:
  - 포지션 목록 (positions)
  - 계좌 잔액 (accounts)
  - 거래내역 PnL% 테이블 + 페이지네이션
  - 수수료 조회 (Backend의 /api/fee 호출)
```

### 4.5 파일 구조

```
tapbit_calc_pro/
├── bookmarklet/                    # 신규
│   ├── sync.js                     # 북마클릿 메인 스크립트
│   ├── sync.min.js                 # 압축 버전
│   └── README.md                   # 설치 가이드
│
├── backend/                        # 신규
│   ├── api/
│   │   ├── sync.js                 # POST /api/sync
│   │   ├── data.js                 # GET /api/data
│   │   └── fee.js                  # POST /api/fee
│   ├── lib/
│   │   └── db.js                   # DB 접근 레이어
│   └── package.json
│
├── coinstep-calc/
│   └── calc.jsx                    # chrome.storage → fetch API로 변경
│
├── extensions/                     # 기존 유지 (하위 호환)
│   └── ...
```

### 4.6 데이터 흐름 비교

```
현재 (확장):
  Tapbit → inject-tapbit.js → content-tapbit.js → background.js
  → chrome.storage → content-calc.js → calc.jsx

제안 (웹):
  Tapbit → 북마클릿(sync.js) → Backend API
  → DB → Coinstep fetch → calc.jsx
```

---

## 5. Risk Analysis

| 리스크 | 영향 | 대응 |
|--------|------|------|
| ~~Tapbit CSP가 외부 스크립트 차단~~ | ~~북마클릿 로더 방식 불가~~ | **검증 완료 (2026-03-10): CSP 없음, 외부 스크립트 로딩 성공. jsdelivr CDN 로더 방식 사용 가능** |
| Tapbit dva store 구조 변경 | sync.js 작동 불가 | 확장과 동일한 리스크, 버전 체크 로직 추가 |
| 대량 데이터 전송 (700건+) | POST 요청 크기 초과 | 청크 분할 전송 또는 압축 |
| 북마클릿 코드 노출 (GitHub 공개) | API 키 노출 위험 | API 키는 환경변수, 스크립트에 미포함 |
| 자동 갱신 불가 | UX 저하 | "동기화" 안내 메시지, 최신 sync 시간 표시 |

---

## 6. Implementation Order

| 순서 | 작업 | 의존성 |
|------|------|--------|
| ~~1~~ | ~~CSP 검증~~ | **완료: CSP 없음, jsdelivr CDN 로딩 성공 확인** |
| 2 | Backend API 구축 (POST /api/sync, GET /api/data) | 없음 |
| 3 | sync.js 북마클릿 스크립트 개발 | CSP 결과에 따라 방식 결정 |
| 4 | calc.jsx 프론트엔드 개편 (chrome.storage → fetch) | Backend API |
| 5 | 수수료 조회 기능 (POST /api/fee) | Backend + histories 저장 |
| 6 | 설치 가이드 (README + 드래그 UI) | sync.js 완성 |
| 7 | 테스트 (수십명 시뮬레이션) | 전체 |

---

## 7. Brainstorming Log

| 단계 | 결정 | 이유 |
|------|------|------|
| API 호출 주체 | 사용자 브라우저 (북마클릿) | IP 분산, Tapbit 인증 문제 회피 |
| Backend 역할 | 데이터 저장/조회만 | Tapbit API 직접 호출하지 않아 IP 차단 위험 제거 |
| 확장 코드 재사용 | inject-tapbit.js의 dva dispatch 로직 → sync.js로 이식 | 검증된 로직, 페이지네이션 포함 |
| 자동 갱신 | v1에서 제외 | 북마클릿 특성상 수동만 가능, 충분히 사용 가능 |
| 기존 확장 | 삭제하지 않고 유지 | 하위 호환, 자동 갱신이 필요한 사용자용 |

---

## 8. Version Info

| 항목 | 내용 |
|------|------|
| 현재 버전 | v1.2.0 (Chrome 확장 기반) |
| 목표 버전 | v2.0.0 (웹 기반 동기화) |
| 신규 파일 | bookmarklet/sync.js, backend/api/*.js |
| 수정 파일 | coinstep-calc/calc.jsx |
| 유지 파일 | extensions/* (하위 호환) |
