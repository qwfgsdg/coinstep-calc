# Design: 확장 프로그램 없는 Web 동기화

> 생성일: 2026-03-10 | Plan: web-sync.plan.md
> 작성: CTO Team (Backend Expert + Frontend Architect + Security Architect)

---

## Executive Summary

| 관점 | 내용 |
|------|------|
| **Problem** | Chrome 확장 설치 번거로움, 수십명 온보딩 어려움, 서버 IP 집중 호출 위험 |
| **Solution** | 북마클릿(Tapbit→Backend) + REST API + Coinstep 프론트엔드 개편 |
| **Function UX Effect** | 드래그 1회 설치, Tapbit에서 클릭 → Coinstep에서 즉시 확인 |
| **Core Value** | 설치 없는 온보딩 + 모든 브라우저 + API IP 분산 |

---

## 1. 시스템 아키텍처

```
[사용자 브라우저 — agent.tapbit.com]
  │ 북마클릿 클릭
  ├─ sync.js 로드 (자체 호스팅 HTTPS)
  │  ├─ window.g_app._store 접근
  │  ├─ lists/filtersChange + pageChange dispatch (pagination)
  │  ├─ positions, accounts, histories, profile 수집
  │  └─ POST /api/sync → Backend (Authorization: SyncToken stk_xxx)
  │
[Coinstep Backend API]
  │  ├─ POST /api/sync         ← 북마클릿에서 데이터 수신
  │  ├─ GET  /api/data          ← 프론트엔드 데이터 조회
  │  ├─ POST /api/fee           ← 수수료 계산 (histories 기반)
  │  └─ GET  /api/sync/status   ← 동기화 상태 확인
  │
[Coinstep Frontend — calc.jsx]
  └─ fetch API로 Backend 데이터 읽기 (chrome.storage 대체)
```

### 1.1 핵심 설계 원칙

- **Tapbit API는 사용자 브라우저에서만 호출** (IP 분산, 인증 문제 회피)
- **Backend는 저장/조회만** (Tapbit API 직접 호출 없음)
- **Extension과 공존** (기존 사용자 영향 없음)
- **CSP 검증 완료**: Tapbit 페이지에 CSP 없음, 외부 스크립트 로딩 성공 확인 (2026-03-10)

---

## 2. 인증 설계

### 2.1 두 가지 인증 경로

| 경로 | 대상 | 방식 | 용도 |
|------|------|------|------|
| SyncToken | 북마클릿 | `Authorization: SyncToken stk_xxx` | 데이터 제출 |
| JWT | Coinstep 프론트엔드 | `Authorization: Bearer {token}` | 데이터 조회 |

### 2.2 SyncToken 설계

- **형식**: `stk_` + 랜덤 64자 hex (총 68자, 256비트 엔트로피)
- **생성**: 서버에서 `crypto.randomBytes(32).toString('hex')`
- **DB 저장**: bcrypt 해시 (원문은 발급 시 1회만 노출)
- **만료**: 없음 (관리자가 수동 재발급/폐기)
- **사용자↔토큰 바인딩**: 토큰이 특정 userId에 고정, 요청 본문의 maskId는 토큰 소유자와 일치 여부 검증

### 2.3 사용자 온보딩 플로우

```
1. 관리자가 Coinstep에서 사용자 등록 (email + tapbitMaskId)
2. 시스템이 syncToken 생성 → 화면에 1회 표시
3. 사용자가 syncToken 복사
4. 북마클릿 최초 실행 시 syncToken 입력 (prompt)
5. 북마클릿이 localStorage(agent.tapbit.com)에 토큰 저장
6. 이후 클릭만으로 자동 동기화
```

---

## 3. 북마클릿 설계 (sync.js)

### 3.1 로더

```
javascript:(function(){var s=document.createElement('script');
s.src='https://api.coinstep.co.kr/static/sync.js?v='+Date.now();
document.head.appendChild(s)})()
```

**호스팅**: Coinstep 백엔드와 동일 도메인 (jsdelivr CDN 의존 탈피, 보안 강화)

### 3.2 실행 흐름

```
1. dva store 존재 확인
   - window.g_app?._store 없으면 → 에러 toast "Tapbit 페이지에서 실행하세요"

2. syncToken 확인
   - localStorage.getItem('coinstep_sync_token')
   - 없으면 → prompt("Coinstep SyncToken을 입력하세요") → 저장

3. 데이터 수집 (기존 확장 로직 재사용)
   - profile: store.getState()에서 maskId, remarkName
   - positions: __TAPBIT_POSITIONS__ 메시지 수신 또는 store에서 직접 읽기
   - accounts: __TAPBIT_ACCOUNTS__ 메시지 수신 또는 store에서 직접 읽기
   - histories: lists/filtersChange dispatch → 페이지네이션 (list.length === 100이면 pageChange)

4. 진행 상태 표시 (toast UI)
   - "데이터 수집 중... (1/3 페이지)"
   - "서버로 전송 중..."
   - "동기화 완료! (452건)"

5. Backend 전송
   - POST https://api.coinstep.co.kr/api/sync
   - Authorization: SyncToken stk_xxx
   - Body: { profile, positions, accounts, histories, checksum }

6. 결과 표시
   - 성공: 초록 toast "동기화 완료 (452건, 3초)"
   - 실패: 빨간 toast + 에러 메시지
```

### 3.3 페이지네이션 처리 (histories)

기존 background.js FETCH_SUMMARY 로직을 그대로 이식:

```
- lists/filtersChange dispatch → 1페이지 수신
- list.length === 100 → lists/pageChange dispatch
- 모든 페이지 누적 (MAX_PAGES=50, 최대 5000건)
- 30초 타임아웃, 부분 데이터도 전송 (partial: true 마킹)
```

### 3.4 중복 실행 방지

```
- window.__COINSTEP_SYNCING 플래그
- 실행 중이면 toast "이미 동기화 중입니다" → 무시
- 완료/실패 시 플래그 해제
```

---

## 4. Backend API 설계

### 4.1 데이터베이스 스키마

**users** (bkend 내장 auth + 확장 필드)

| 필드 | 타입 | 설명 |
|------|------|------|
| id | String (auto) | |
| email | String (unique) | 로그인용 |
| tapbitMaskId | String (unique) | Tapbit 사용자 식별 |
| remarkName | String | 별명 |
| syncTokenHash | String | bcrypt 해시 |
| lastSyncedAt | Date | 마지막 동기화 |
| isActive | Boolean | 계정 활성 |

**sync_snapshots** (동기화 세션)

| 필드 | 타입 | 설명 |
|------|------|------|
| id | String (auto) | |
| userId | String (index) | |
| status | String | "pending" / "completed" / "failed" |
| positionCount | Number | |
| accountCount | Number | |
| historyCount | Number | |
| checksum | String | MD5 (중복 제출 감지) |
| serverTimestamp | Date | |

**positions** (최신 1개 스냅샷만 유지, 동기화 시 교체)

| 필드 | 타입 | 설명 |
|------|------|------|
| id | String (auto) | |
| userId | String (index) | |
| tapbitMaskId | String (index) | |
| rawData | Object | 원본 데이터 전체 |
| snapshotAt | Date | |

**accounts** (최신 1개 스냅샷만 유지)

| 필드 | 타입 | 설명 |
|------|------|------|
| id | String (auto) | |
| userId | String (index) | |
| tapbitMaskId | String (index) | |
| rawData | Object | 원본 데이터 전체 |
| snapshotAt | Date | |

**histories** (누적, tradeId 기준 중복 방지)

| 필드 | 타입 | 설명 |
|------|------|------|
| id | String (auto) | |
| userId | String (index) | |
| tapbitMaskId | String (index) | |
| tradeId | String | Tapbit 거래 고유 ID |
| tradeFee | Number | 수수료 |
| tradeAt | Date (index) | 거래 시각 |
| rawData | Object | 원본 전체 |

**인덱스**: (userId, tradeId) unique, (userId, tradeAt) 복합

### 4.2 API 엔드포인트

#### POST /api/sync (북마클릿 → 백엔드)

```
Headers:
  Authorization: SyncToken stk_xxx
  Content-Type: application/json

Body:
{
  "checksum": "md5_of_payload",
  "profile": { "maskId": "xxx", "remarkName": "xxx" },
  "positions": [ { ...rawData } ],
  "accounts": [ { ...rawData } ],
  "histories": [ { "tradeId": "xxx", ...rawData } ]
}

Response (성공):
{
  "success": true,
  "snapshotId": "snap_xxx",
  "counts": {
    "positions": 3,
    "accounts": 2,
    "historiesInserted": 45,
    "historiesSkipped": 667
  }
}
```

서버 처리:
1. syncToken 검증 → userId 식별
2. checksum으로 5분 내 중복 요청 감지 → 중복이면 기존 결과 반환
3. pending 상태 snapshot 존재 확인 → 있으면 409 SYNC_IN_PROGRESS
4. sync_snapshots "pending" 생성
5. positions, accounts: 기존 삭제 후 새로 삽입
6. histories: tradeId 기준 upsert (존재하면 skip)
7. snapshot "completed" 업데이트
8. users.lastSyncedAt 업데이트

#### GET /api/data (프론트엔드 → 백엔드)

```
Headers:
  Authorization: Bearer {jwt}
Query:
  ?startDate=2026-03-01&endDate=2026-03-10

Response:
{
  "positions": [...],
  "accounts": [...],
  "histories": [...],
  "profile": { "maskId": "xxx", "remarkName": "xxx" },
  "meta": {
    "lastSyncedAt": "2026-03-10T12:00:00Z",
    "syncComplete": true,
    "recordCount": 452
  }
}
```

#### POST /api/fee (수수료 계산)

```
Headers:
  Authorization: Bearer {jwt}
Body:
  { "startDate": "2026-03-01", "endDate": "2026-03-10" }

Response:
{
  "totalFee": 2316.26,
  "recordCount": 452,
  "traders": 5
}
```

Backend에서 저장된 histories의 tradeFee를 필터링하여 합산. Tapbit API 호출 없음.

#### GET /api/sync/status

```
Headers: Authorization: Bearer {jwt}

Response:
{
  "hasSyncedData": true,
  "lastSyncedAt": "2026-03-10T12:00:00Z",
  "syncSource": "bookmarklet",
  "syncComplete": true
}
```

### 4.3 CORS 설정

```
허용 출처:
  - https://agent.tapbit.com    (북마클릿)
  - https://pro.coinstep.co.kr  (프론트엔드)

허용 메서드: GET, POST, OPTIONS
허용 헤더: Content-Type, Authorization
Credentials: false (토큰은 Authorization 헤더로)
Preflight 캐시: 3600초
```

**와일드카드(*) 절대 금지**

### 4.4 Rate Limiting

| 대상 | 제한 | 초과 시 |
|------|------|---------|
| 동기화 (SyncToken) | 10회/시간, 3회/분 | 429 + Retry-After |
| 조회 (JWT) | 100회/시간 | 429 |
| 동시 동기화 | 1개/사용자 | 409 SYNC_IN_PROGRESS |

### 4.5 데이터 보존

| 데이터 | 보존 | 관리 |
|--------|------|------|
| positions, accounts | 최신 1개만 | 동기화 시 교체 |
| histories | 180일 | 일 1회 배치 삭제 |
| sync_snapshots | 30일 | 일 1회 배치 삭제 |

### 4.6 에러 코드

| HTTP | 코드 | 상황 |
|------|------|------|
| 400 | INVALID_PAYLOAD | 필수 필드 누락 |
| 401 | INVALID_SYNC_TOKEN | 토큰 불일치 |
| 409 | SYNC_IN_PROGRESS | 동시 동기화 |
| 409 | DUPLICATE_REQUEST | checksum 중복 (5분) |
| 422 | MASKID_MISMATCH | 토큰↔maskId 불일치 |
| 429 | RATE_LIMIT_EXCEEDED | 빈도 초과 |

---

## 5. 프론트엔드 설계 (calc.jsx)

### 5.1 모드 감지

```
우선순위:
1. URL 파라미터: ?mode=web-sync
2. localStorage 저장값
3. 자동 감지: typeof chrome !== 'undefined' && chrome.storage → Extension
   그 외 → Web-Sync
```

### 5.2 Chrome Storage → Backend API 전환

**래퍼 패턴** (기존 6400줄 코드 최소 변경):

```
기존: chrome.storage.local.get("tapbitData", callback)
변경: getStorageData("tapbitData", callback)

getStorageData 내부:
  if (webSyncMode) → fetch('/api/data') → 변환 → callback
  else → chrome.storage.local.get → callback
```

### 5.3 데이터 Freshness 표시

```
FRESH:    lastSyncedAt < 30분    → 정상 표시
STALE:    30분 ~ 2시간           → 노란 배너 "1시간 전 동기화"
VERY_OLD: 2시간+                 → 빨간 배너 "재동기화 필요"
NO_DATA:  hasSyncedData=false    → 온보딩 안내 화면
```

### 5.4 수수료 조회 변경

```
기존 (Extension):
  chrome.runtime.sendMessage({ type: "FETCH_SUMMARY" })
  → background.js → Tapbit dva dispatch → executeScript

변경 (Web-Sync):
  fetch('/api/fee', { body: { startDate, endDate } })
  → Backend에서 저장된 histories 필터링 → tradeFee 합산
  → 응답 표시
```

Tapbit API 호출 없이 Backend에 이미 저장된 데이터로 계산. 페이지네이션도 이미 북마클릿이 완료했으므로 추가 처리 불필요.

### 5.5 날짜 보존

```
기존: savedStartDate/savedEndDate 모듈 변수

변경:
1. sessionStorage에 저장 (세션 내 유지)
2. URL 파라미터에 반영 (replaceState, 공유 가능)
3. API 호출 시 query parameter로 전달
4. 새로고침 후에도 URL에서 복원
```

### 5.6 경쟁 조건 방지

| 시나리오 | 해결 |
|----------|------|
| 날짜 변경 중 기존 fetch 응답 도착 | AbortController: 새 요청 시 이전 abort |
| 탭 복귀 + 수동 새로고침 동시 발생 | isRefreshing 플래그 잠금 + 300ms 디바운스 |
| 북마클릿 부분 완료 중 프론트 폴링 | syncComplete 마커: false이면 "동기화 중..." 표시 |

### 5.7 폴링 전략

```
- 마운트 시 즉시 1회 fetch
- 탭 visible일 때만 5분 간격 폴링
- 탭 background이면 중단
- 탭 포커스 복귀 시 즉시 1회 fetch
- 네트워크 오류: exponential backoff (1s→2s→4s→max 30s)
```

---

## 6. 보안 설계

### 6.1 위협 모델 요약

| 위협 | 심각도 | 대응 |
|------|--------|------|
| CDN 스크립트 변조 | High | 자체 HTTPS 호스팅 (CDN 의존 탈피) |
| API 키 노출 | Critical | 사용자별 SyncToken, 코드에 하드코딩 금지 |
| 가짜 데이터 제출 | High | 스키마 검증 + 감사 로그 + Rate Limiting |
| 사용자 사칭 | High | 토큰↔userId 고정 바인딩, maskId 검증 |
| XSS | Medium | innerHTML 금지, textContent만 사용 |

### 6.2 보안 헤더 (Backend 응답)

```
Strict-Transport-Security: max-age=31536000; includeSubDomains
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Cache-Control: no-store
```

### 6.3 저장 금지 데이터

- Tapbit 로그인 자격 증명 (아이디, 비밀번호)
- Tapbit 세션 토큰/쿠키
- 출금 주소, 개인 키
- 개인 식별 정보 (주민번호, 실명 등)

---

## 7. 구현 순서

| Phase | 작업 | 파일 | 의존성 |
|-------|------|------|--------|
| **1** | Backend API 기본 (POST /sync, GET /data) | backend/ | 없음 |
| **1** | DB 스키마 생성 (users, positions, accounts, histories) | backend/ | 없음 |
| **1** | SyncToken 발급/검증 | backend/ | DB |
| **2** | sync.js 북마클릿 개발 | bookmarklet/ | Backend API |
| **2** | CORS 설정 (agent.tapbit.com 허용) | backend/ | 없음 |
| **3** | calc.jsx 모드 감지 + 래퍼 패턴 | coinstep-calc/ | Backend API |
| **3** | 수수료 조회 (POST /api/fee) | backend/ + calc.jsx | histories 저장 |
| **4** | Freshness UI + 폴링 | calc.jsx | Phase 3 |
| **4** | 날짜 보존 (sessionStorage + URL) | calc.jsx | Phase 3 |
| **5** | Rate Limiting + 감사 로그 | backend/ | Phase 1 |
| **5** | 에러 처리 + AbortController | calc.jsx | Phase 3 |
| **6** | 설치 가이드 (README + UI) | bookmarklet/ | Phase 2 |
| **6** | 관리자 대시보드 (사용자 관리) | calc.jsx + backend/ | 전체 |

---

## 8. 파일 구조

```
tapbit_calc_pro/
├── bookmarklet/                 # 신규
│   ├── sync.js                  # 북마클릿 메인 (dva dispatch + Backend POST)
│   └── README.md                # 설치 가이드
│
├── backend/                     # 신규
│   ├── api/
│   │   ├── sync.js              # POST /api/sync (데이터 수신)
│   │   ├── data.js              # GET /api/data (데이터 조회)
│   │   ├── fee.js               # POST /api/fee (수수료 계산)
│   │   └── sync-status.js       # GET /api/sync/status
│   ├── lib/
│   │   ├── db.js                # DB 접근 레이어
│   │   ├── auth.js              # SyncToken/JWT 검증
│   │   └── cors.js              # CORS 미들웨어
│   └── package.json
│
├── coinstep-calc/
│   └── calc.jsx                 # 모드 감지 + 래퍼 패턴으로 최소 변경
│
├── extensions/                  # 기존 유지 (하위 호환)
│   └── ...
```

---

## 9. Extension과의 공존 전략

```
Extension 사용자:
  - 기존 코드 변경 없음
  - chrome.storage 기반 flow 유지
  - content-calc.js 그대로 동작

Web-Sync 사용자:
  - Extension 미설치
  - calc.jsx가 자동으로 Web-Sync 모드 진입
  - Backend API 기반 flow

혼용 방지:
  - calc.jsx가 모드를 한 가지만 사용 (자동 감지 또는 명시 설정)
  - Web-Sync 모드에서는 chrome.storage 이벤트 무시
  - Extension 모드에서는 Backend API 호출 안 함
```
