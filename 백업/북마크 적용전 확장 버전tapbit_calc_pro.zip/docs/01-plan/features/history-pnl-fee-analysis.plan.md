# Plan: 거래내역 PnL% 표시 + 수수료 분석

> Plan Plus (Brainstorming-Enhanced) | 생성일: 2026-03-09

---

## Executive Summary

| 항목 | 내용 |
|------|------|
| Feature | 거래내역 PnL% 표시 + 수수료 분석 |
| 생성일 | 2026-03-09 |
| 예상 범위 | Chrome 확장 v1.2.0 |

| 관점 | 내용 |
|------|------|
| **Problem** | Tapbit 거래내역에서 손익 금액만 보이고 손익률(%)이 없어 수익성 판단이 어려움. 회원별/기간별 수수료 집계도 수동으로 해야 함 |
| **Solution** | histories API 응답을 가로채 PnL% 컬럼을 DOM에 주입하고, summary API로 수수료 요약 패널을 제공 |
| **Function UX Effect** | 거래 테이블에서 바로 손익률 확인 + 날짜/회원 필터로 수수료 즉시 조회 |
| **Core Value** | 에이전트의 회원별 수익성 분석 및 수수료 관리 효율화 |

---

## 1. User Intent Discovery

### Core Problem
- Tapbit historyOrders 페이지에서 각 거래의 **손익 금액(profit)**만 표시되고 **손익률(%)**이 없음
- 수수료 반영 전/후 손익률을 한눈에 비교할 수 없음
- 회원별/기간별 **수수료 합계**를 확인하려면 수동 계산 필요

### Target Users
- Tapbit 에이전트 관리자 (agent.tapbit.com 사용자)

### Success Criteria
- 각 거래 행에 PnL%(순수)와 PnL%(수수료 반영)이 표시됨
- 마진 기준 / 거래금액 기준 전환 가능
- 날짜 범위 + 회원 선택으로 수수료 합계 조회 가능
- 회원 미선택 시 전체 회원 수수료 합계 표시

---

## 2. Alternatives Explored

### Approach A: Tapbit 페이지에 UI 주입 -- 선택됨
- **장점**: Tapbit 페이지 안에서 바로 확인, 별도 페이지 불필요
- **단점**: DOM 구조 변경 시 깨질 수 있음
- **선택 이유**: 가장 자연스러운 UX, 기존 확장의 fetch 가로채기 패턴 재활용

### Approach B: 확장 팝업 대시보드
- **장점**: Tapbit DOM에 의존하지 않음
- **단점**: 팝업 열어야 하는 추가 동작, 공간 제약

### Approach C: 하이브리드
- **장점**: 역할 분리
- **단점**: 구현 복잡도 증가, 유지보수 비용

---

## 3. YAGNI Review

### v1 포함 (필수)
- [x] PnL% 컬럼 주입 (수수료 미반영 / 반영 둘 다)
- [x] 마진 기준 / 거래금액 기준 전환 토글
- [x] 날짜별 수수료 요약 패널 (날짜 범위 선택)
- [x] 회원별 / 전체 수수료 필터

### Out of Scope (v1에서 제외)
- 상위 에이전트명(parentRemarkName) 표시
- 거래 내역 CSV 내보내기
- 차트/그래프 시각화
- 실시간 자동 갱신

---

## 4. Technical Design

### 4.1 API 엔드포인트

#### 거래내역 API
```
GET https://agent-api.tapbit.com/agent/contract/order/histories
Parameters:
  - contractType: USDT_MARGIN_CONTRACT
  - startTime: {밀리초 timestamp}
  - endTime: {밀리초 timestamp}
  - pageNumber: {페이지 번호}
  - pageSize: {페이지 크기}
  - auth: {인증 토큰}

Response (data.list[n].data):
  - profit: "0.6786"         // 손익 금액
  - tradeFee: "0.9399312"    // 수수료
  - tradeAmount: "2349.828"  // 거래 금액
  - leverage: 50             // 레버리지 (거래마다 다름)
  - contractName: "ETHUSDT"  // 거래쌍
  - createTime: 1773035871000 // 거래시간

Response (data.list[n] 상위):
  - maskId: 96876510         // 회원 식별자
  - remarkName: "메모"       // 회원 메모
```

#### 수수료 요약 API
```
GET https://agent-api.tapbit.com/agent/contract/order/history/summary
Parameters:
  - contractType: USDT_MARGIN_CONTRACT
  - userType: (빈값 = 전체)
  - startTime: {밀리초 timestamp}
  - endTime: {밀리초 timestamp}
  - auth: {인증 토큰}

Response:
  - totalCustomerTraders: "2"        // 거래 회원 수
  - totalCustomerTradeFees: "96.006331" // 총 수수료
```

### 4.2 PnL% 계산 로직

```javascript
// 각 거래마다 data 필드에서 값 추출
const leverage = data.leverage;           // 거래별 동적 레버리지
const tradeAmount = parseFloat(data.tradeAmount);
const profit = parseFloat(data.profit);
const tradeFee = parseFloat(data.tradeFee);

// 마진 기준 (기본)
const margin = tradeAmount / leverage;
const pnlPctPure = (profit / margin) * 100;           // 수수료 미반영
const pnlPctWithFee = ((profit - tradeFee) / margin) * 100; // 수수료 반영

// 거래금액 기준 (선택)
const pnlPctByAmount = (profit / tradeAmount) * 100;
const pnlPctByAmountWithFee = ((profit - tradeFee) / tradeAmount) * 100;
```

### 4.3 파일 구조 변경

```
extensions/
├── manifest.json          // host_permissions에 agent-api 이미 포함
├── background.js          // auth 저장 + summary API 호출 추가
├── content-tapbit.js      // 수수료 패널 DOM 주입 + 메시지 중계 추가
├── inject-tapbit.js       // histories 응답 캡처 + PnL% 컬럼 주입 추가
├── popup.html             // 변경 없음
└── popup.js               // 변경 없음
```

### 4.4 구현 흐름

#### 흐름 1: PnL% 컬럼 주입
```
1. inject-tapbit.js: histories API 응답 가로채기
   - URL 패턴: /agent/contract/order/histories
   - 응답 JSON의 data.list 각 항목에서 profit, tradeFee, tradeAmount, leverage 추출

2. PnL% 계산 후 DOM 주입
   - 기존 테이블의 각 행에 2개 컬럼 추가
   - 컬럼 1: PnL%(순수) — 수수료 미반영
   - 컬럼 2: PnL%(수수료) — 수수료 반영
   - 양수는 초록색, 음수는 빨간색

3. 토글 버튼
   - 마진 기준(기본) ↔ 거래금액 기준 전환
   - 테이블 상단에 작은 토글 배치
```

#### 흐름 2: 수수료 요약 패널
```
1. historyOrders 페이지 감지 시 상단에 요약 패널 DOM 주입

2. 패널 UI:
   - 회원 드롭다운: [전체] / [회원1] / [회원2] / ...
     → histories API의 list에서 maskId + remarkName 추출하여 목록 생성
   - 날짜 범위: [시작일] ~ [종료일] date picker
   - 조회 버튼

3. 조회 시:
   - summary API 호출 (auth 재사용, startTime/endTime 변환)
   - 회원 지정 시: userType 파라미터에 회원 정보 전달
   - 결과 표시: 총수수료(USDT) + 거래회원수
```

### 4.5 auth 토큰 관리

```
현재: inject-tapbit.js가 URL에서 auth= 파라미터를 캡처 → content-tapbit.js 경유 → background.js에 저장
추가: summary API 직접 호출 시 저장된 auth를 재사용
```

---

## 5. Brainstorming Log

| 단계 | 결정 | 이유 |
|------|------|------|
| PnL% 기준 | 마진 기본 + 거래금액 선택 | 마진 기준이 실제 투자 대비 수익률로 더 의미 있음 |
| 레버리지 | 각 거래별 동적 값 사용 | 회원/거래마다 레버리지가 다를 수 있음 |
| 구현 위치 | Tapbit 페이지 내 DOM 주입 | 가장 자연스러운 UX, 기존 패턴 재활용 |
| 상위 에이전트명 | 제외 | 불필요하다는 사용자 결정 |
| 날짜 범위 | from-to 방식 | 단일 날짜만이 아닌 기간 조회 필요 |

---

## 6. Version Info

| 항목 | 내용 |
|------|------|
| 현재 버전 | v1.1.0 |
| 목표 버전 | v1.2.0 |
| 수정 파일 | inject-tapbit.js, content-tapbit.js, background.js, manifest.json |
| 신규 파일 | 없음 |
