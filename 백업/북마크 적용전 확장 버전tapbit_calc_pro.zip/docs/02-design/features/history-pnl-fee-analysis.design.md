# History PnL% & Fee Analysis — Design Document

> **Summary**: Tapbit 거래내역 페이지에 PnL% 컬럼 주입 + 수수료 요약 패널 UI 주입
>
> **Project**: Coinstep Tapbit 동기화 Chrome 확장
> **Version**: v1.1.0 → v1.2.0
> **Date**: 2026-03-09
> **Status**: Draft
> **Planning Doc**: [history-pnl-fee-analysis.plan.md](../01-plan/features/history-pnl-fee-analysis.plan.md)

---

## 1. Overview

### 1.1 Design Goals

1. histories API 응답을 가로채서 PnL% 2개 컬럼을 테이블에 주입
2. 수수료 요약 패널을 페이지 상단에 주입 (날짜 범위 + 회원 필터)
3. 기존 확장 코드(v1.1.0)와의 호환성 유지

### 1.2 Design Principles

- **최소 침습**: Tapbit 페이지 기존 기능에 영향 없이 UI만 추가
- **기존 패턴 재사용**: inject-tapbit.js의 fetch 가로채기 패턴 확장
- **단일 파일 책임**: inject-tapbit.js(PnL% 주입), content-tapbit.js(수수료 패널), background.js(API 호출)

---

## 2. Architecture

### 2.1 Component Diagram

```
┌─────────────────────────────────────────────────────────────┐
│ Tapbit historyOrders 페이지 (agent.tapbit.com)              │
│                                                             │
│  ┌─────────────────────────────────────────────────┐        │
│  │ inject-tapbit.js (MAIN world)                   │        │
│  │  ├─ fetch 가로채기 (기존 + histories 추가)       │        │
│  │  ├─ PnL% 계산 엔진                              │        │
│  │  └─ 테이블 DOM 조작 (컬럼 주입 + 토글)          │        │
│  └──────────────────────┬──────────────────────────┘        │
│                         │ window.postMessage                │
│  ┌──────────────────────▼──────────────────────────┐        │
│  │ content-tapbit.js (content script)              │        │
│  │  ├─ 메시지 중계 (기존)                           │        │
│  │  ├─ 수수료 요약 패널 DOM 주입                    │        │
│  │  └─ 날짜/회원 필터 UI 이벤트 처리               │        │
│  └──────────────────────┬──────────────────────────┘        │
│                         │ chrome.runtime.sendMessage        │
└─────────────────────────┼───────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────┐
│ background.js (service worker)                              │
│  ├─ auth 토큰 저장 (기존)                                   │
│  ├─ summary API 호출 (날짜/회원 변경 시)                    │
│  └─ 수수료 결과를 content-tapbit.js로 반환                  │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 Data Flow

```
Flow 1: PnL% 컬럼 주입
─────────────────────────────────────────────────────
Tapbit 서버 ──(histories API 응답)──▶ inject-tapbit.js
                                         │
                                    fetch 가로채기
                                    응답 clone + parse
                                         │
                                    PnL% 계산
                                    (profit, tradeFee, tradeAmount, leverage)
                                         │
                                    DOM 조작: ant-table 행에 컬럼 주입
                                    (MutationObserver로 테이블 변경 감지)


Flow 2: 수수료 요약
─────────────────────────────────────────────────────
content-tapbit.js ──(패널 DOM 주입)──▶ 페이지 상단
        │
   사용자: 날짜/회원 선택 후 조회 클릭
        │
   chrome.runtime.sendMessage({type: "FETCH_SUMMARY", ...})
        │
        ▼
background.js ──(summary API 직접 호출)──▶ agent-api.tapbit.com
        │
   응답 수신: totalCustomerTradeFees, totalCustomerTraders
        │
        ▼
content-tapbit.js ──(결과 표시)──▶ 패널 UI 업데이트
```

### 2.3 Dependencies

| Component | Depends On | Purpose |
|-----------|-----------|---------|
| inject-tapbit.js (PnL%) | histories API 응답 구조 | 데이터 추출 |
| inject-tapbit.js (DOM) | Ant Design 테이블 DOM 구조 | 컬럼 주입 위치 |
| content-tapbit.js (패널) | background.js auth 저장 | summary API 호출 |
| background.js (summary) | auth 토큰 | API 인증 |

---

## 3. Data Model

### 3.1 API 응답 → 내부 데이터 구조

```javascript
// histories API 응답에서 추출하는 거래 데이터
// data.list[n].data 필드
const TradeData = {
  orderId: Number,          // 주문 ID
  contractName: String,     // "ETHUSDT"
  contractType: String,     // "USDT_MARGIN_CONTRACT"
  profit: String,           // "0.6786" — 손익 금액 (USDT)
  tradeFee: String,         // "0.9399312" — 수수료 (USDT)
  tradeAmount: String,      // "2349.828" — 거래 금액 (USDT)
  leverage: Number,         // 50 — 레버리지 (거래별 동적)
  direction: Number,        // 4 — 매매 방향
  createTime: Number,       // 1773035871000 — 밀리초 timestamp
  tradeAveragePrice: String,// "2008.4"
  quantity: Number,         // 117
};

// data.list[n] 상위 — 회원 정보
const MemberData = {
  maskId: Number,           // 96876510 — 회원 식별자
  remarkName: String,       // "이데일리/뚝억기법/조선족50대"
  channelId: Number,        // 1043850
};

// 계산된 PnL% 데이터 (inject-tapbit.js 내부)
const PnlResult = {
  // 마진 기준
  margin: Number,           // tradeAmount / leverage
  pnlPctPure: Number,       // (profit / margin) * 100
  pnlPctWithFee: Number,    // ((profit - tradeFee) / margin) * 100
  // 거래금액 기준
  pnlPctByAmount: Number,   // (profit / tradeAmount) * 100
  pnlPctByAmountWithFee: Number, // ((profit - tradeFee) / tradeAmount) * 100
};
```

### 3.2 chrome.storage 데이터 추가

```javascript
// 기존 tapbitData에 auth 토큰 추가 저장
{
  tapbitData: { /* 기존 */ },
  tapbitAuth: {
    token: "1773040111-457c2f1f...",  // 최신 auth 토큰
    capturedAt: 1773040111000,         // 캡처 시간
  }
}
```

---

## 4. API Specification

### 4.1 사용하는 Tapbit API

| # | Method | Endpoint | 용도 | 호출 주체 |
|---|--------|----------|------|----------|
| 1 | GET | `/agent/contract/order/histories` | 거래내역 (가로채기) | inject-tapbit.js (fetch intercept) |
| 2 | GET | `/agent/contract/order/history/summary` | 수수료 요약 | background.js (직접 호출) |

### 4.2 histories API 파라미터 (가로채기 대상)

```
GET https://agent-api.tapbit.com/agent/contract/order/histories
  ?contractType=USDT_MARGIN_CONTRACT
  &startTime=1773014400000
  &endTime=1773100799999
  &pageNumber=1
  &pageSize=10
  &auth={token}
```

### 4.3 summary API 파라미터 (직접 호출)

```
GET https://agent-api.tapbit.com/agent/contract/order/history/summary
  ?contractType=USDT_MARGIN_CONTRACT
  &userType=             ← 빈값: 전체 / 값 지정: 특정 회원
  &startTime={ms_timestamp}
  &endTime={ms_timestamp}
  &auth={saved_token}
```

### 4.4 내부 메시지 프로토콜 (Chrome Extension)

| 방향 | type | payload | 설명 |
|------|------|---------|------|
| inject → content | `__TAPBIT_HISTORIES__` | `{data: {list, ...}}` | 거래내역 캡처 데이터 |
| inject → content | `__TAPBIT_AUTH__` | `{auth: string}` | auth 토큰 (기존) |
| content → background | `DATA_HISTORIES` | `{data: {...}}` | 거래내역 중계 |
| content → background | `FETCH_SUMMARY` | `{startTime, endTime, userType}` | 수수료 조회 요청 |
| background → content | `SUMMARY_RESULT` | `{totalCustomerTradeFees, totalCustomerTraders}` | 수수료 결과 |
| content → inject | `__TOGGLE_PNL_MODE__` | `{mode: "margin" \| "amount"}` | PnL% 기준 전환 |

---

## 5. UI/UX Design

### 5.1 PnL% 컬럼 주입 (테이블 내)

```
기존 Ant Design 테이블 (historyOrders)
┌──────────┬────────┬──────────┬──────────┬─────────┬─────────────┬──────────────┐
│ 거래쌍   │ 방향   │ 거래금액 │ 수수료   │ 손익    │ PnL%(순수)  │ PnL%(수수료) │
│          │        │          │          │         │  ← 주입     │  ← 주입      │
├──────────┼────────┼──────────┼──────────┼─────────┼─────────────┼──────────────┤
│ ETHUSDT  │ 매도   │ 2,349.83 │ 0.9399   │ +0.6786 │  +1.44%     │  -0.56%      │
│          │        │          │          │         │  (초록)     │  (빨강)      │
├──────────┼────────┼──────────┼──────────┼─────────┼─────────────┼──────────────┤
│ BTCUSDT  │ 매수   │ 5,120.00 │ 2.0480   │ -3.2100 │  -3.14%     │  -5.14%      │
│          │        │          │          │         │  (빨강)     │  (빨강)      │
└──────────┴────────┴──────────┴──────────┴─────────┴─────────────┴──────────────┘
                                                      ▲
                                            [마진 기준 ↔ 거래금액 기준] 토글
```

**컬럼 주입 규칙:**
- 테이블 헤더(`thead`)에 2개 `th` 추가
- 각 행(`tbody tr`)에 2개 `td` 추가
- 양수: `color: #34d399` (초록), 음수: `color: #f87171` (빨강)
- 소수점 2자리로 표시 (예: +1.44%, -0.56%)

**토글 버튼:**
- 테이블 상단 우측에 작은 텍스트 토글 배치
- 기본: "마진 기준" | 클릭 시: "거래금액 기준"
- 전환 시 모든 PnL% 값 즉시 재계산

### 5.2 수수료 요약 패널 (테이블 상단 주입)

```
┌─────────────────────────────────────────────────────────────────────┐
│  📊 수수료 분석                                          [접기 ▲]  │
│                                                                     │
│  회원: [전체 ▼]     시작일: [2026-01-04]  종료일: [2026-03-08]     │
│                                                   [조회]            │
│                                                                     │
│  ┌──────────────────────┐  ┌──────────────────────┐                │
│  │  총 수수료           │  │  거래 회원수          │                │
│  │  96.006331 USDT      │  │  2명                  │                │
│  └──────────────────────┘  └──────────────────────┘                │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

**패널 상세:**
- 배경: `#0f1120` (Tapbit 다크 테마 매칭)
- 테두리: `1px solid #1e293b`
- 둥근 모서리: `border-radius: 8px`
- 접기/펼치기 토글 가능 (상태 localStorage 저장)

**회원 드롭다운:**
- histories API 응답의 list에서 `maskId` + `remarkName` 쌍 추출
- 중복 제거 후 드롭다운 목록 생성
- "전체" 선택 시 `userType=` (빈값)
- 특정 회원 선택 시 해당 회원의 식별값 전달

**날짜 범위:**
- HTML `<input type="date">` 사용 (네이티브 date picker)
- 기본값: 현재 Tapbit 페이지의 startTime/endTime에서 추출
- 날짜 → 밀리초 timestamp 변환: `new Date(dateStr).getTime()`
- endTime은 해당 날짜 23:59:59.999로 설정

### 5.3 스타일 가이드

```css
/* Tapbit 다크 테마에 맞춘 색상 */
:root {
  --cs-bg-panel: #0f1120;
  --cs-bg-card: #131525;
  --cs-border: #1e293b;
  --cs-text-primary: #e2e8f0;
  --cs-text-secondary: #94a3b8;
  --cs-accent: #3b82f6;
  --cs-profit: #34d399;    /* 이익 — 초록 */
  --cs-loss: #f87171;      /* 손실 — 빨강 */
  --cs-btn-bg: #1e293b;
  --cs-btn-hover: #334155;
}
```

---

## 6. Error Handling

| 상황 | 대응 | UI 표시 |
|------|------|---------|
| histories API 응답 파싱 실패 | 에러 무시, 기존 테이블 유지 | PnL% 컬럼에 "—" 표시 |
| leverage가 0 또는 null | 해당 행 PnL% 계산 스킵 | "—" 표시 |
| tradeAmount가 0 | 0으로 나누기 방지 | "—" 표시 |
| auth 토큰 만료 | summary API 401 에러 | 패널에 "인증 만료. 페이지를 새로고침하세요" |
| summary API 호출 실패 | 에러 메시지 표시 | 패널에 "조회 실패" + 재시도 버튼 |
| DOM 구조 변경 (Ant Table) | 컬럼 주입 실패 시 graceful 처리 | console.warn 로깅, 사용자에겐 무영향 |

---

## 7. Security Considerations

- [x] auth 토큰은 chrome.storage.local에만 저장 (외부 노출 없음)
- [x] summary API 호출은 background.js(service worker)에서만 수행
- [x] inject-tapbit.js는 읽기 전용 (fetch 응답 clone만 사용, 원본 불변)
- [x] XSS 방지: DOM 주입 시 `textContent` 사용 (innerHTML 미사용)
- [x] 외부 CDN/라이브러리 없음 (의존성 공격 면 없음)

---

## 8. Test Plan

### 8.1 수동 테스트 시나리오

| # | 시나리오 | 예상 결과 | 확인 |
|---|---------|----------|------|
| 1 | historyOrders 페이지 로드 | PnL% 2개 컬럼이 테이블에 추가됨 | [ ] |
| 2 | 레버리지 50배 거래 확인 | margin = tradeAmount/50 으로 정확 계산 | [ ] |
| 3 | 레버리지 100배 거래 확인 | margin = tradeAmount/100 으로 정확 계산 | [ ] |
| 4 | 마진↔거래금액 기준 토글 | 모든 PnL% 값이 즉시 변경됨 | [ ] |
| 5 | 수수료 패널: 전체 회원 조회 | totalCustomerTradeFees 합계 표시 | [ ] |
| 6 | 수수료 패널: 특정 회원 선택 | 해당 회원 수수료만 표시 | [ ] |
| 7 | 날짜 범위: 1일 선택 | 해당일 수수료 표시 | [ ] |
| 8 | 날짜 범위: 여러 날 선택 | 기간 내 수수료 합계 표시 | [ ] |
| 9 | 페이지네이션 이동 | 새 페이지에도 PnL% 컬럼 표시 | [ ] |
| 10 | 기존 동기화 기능 | 영향 없이 정상 동작 | [ ] |

### 8.2 Edge Cases

- profit = "0" → PnL% = 0.00% 표시
- tradeFee = "0" → 순수/수수료 PnL%가 동일
- leverage = 0 또는 null → "—" 표시
- 거래내역 없는 기간 → "데이터 없음" 표시
- auth 만료 → 재로그인 안내

---

## 9. Implementation Guide

### 9.1 파일 수정 범위

```
extensions/
├── manifest.json          ← 변경: version 1.2.0
├── background.js          ← 수정: auth 저장 + FETCH_SUMMARY 핸들러
├── content-tapbit.js      ← 수정: 수수료 패널 주입 + 메시지 추가
├── inject-tapbit.js       ← 수정: histories 캡처 + PnL% 컬럼 주입
├── popup.html             ← 변경 없음
└── popup.js               ← 변경 없음
```

### 9.2 Implementation Order

```
1. [ ] inject-tapbit.js — histories API 응답 가로채기
       - /agent/contract/order/histories URL 패턴 감지
       - 응답 clone → JSON parse → data.list 추출
       - window.postMessage로 content에 전달

2. [ ] inject-tapbit.js — PnL% 계산 + 테이블 컬럼 주입
       - calcPnl(data) 함수 구현
       - MutationObserver로 ant-table 변경 감지
       - thead에 헤더 2개, tbody 각 tr에 td 2개 주입
       - 토글 버튼 (마진/거래금액 기준)

3. [ ] background.js — auth 토큰 저장 강화
       - DATA_AUTH 수신 시 chrome.storage.local에 tapbitAuth 저장
       - FETCH_SUMMARY 핸들러 추가

4. [ ] background.js — summary API 호출 로직
       - FETCH_SUMMARY 메시지 수신
       - 저장된 auth로 summary API GET 호출
       - 결과를 SUMMARY_RESULT로 content에 반환

5. [ ] content-tapbit.js — 수수료 요약 패널 DOM 주입
       - historyOrders URL 감지 시 패널 생성
       - 회원 드롭다운 (histories 데이터에서 추출)
       - 날짜 범위 input (기본값: 현재 페이지 날짜)
       - 조회 버튼 → FETCH_SUMMARY 메시지 전송

6. [ ] content-tapbit.js — 수수료 결과 표시
       - SUMMARY_RESULT 수신 → 패널 UI 업데이트
       - 에러 처리 (401, 네트워크 오류 등)

7. [ ] manifest.json — 버전 업데이트 (1.2.0)

8. [ ] 통합 테스트 — 전체 흐름 검증
```

### 9.3 핵심 구현 상세

#### 9.3.1 histories 가로채기 (inject-tapbit.js 추가)

```javascript
// inject-tapbit.js에 추가할 패턴
if (url.includes("/agent/contract/order/histories")) {
  const cloned = result.clone();
  const json = await cloned.json();
  if (json?.data?.list) {
    // PnL% 계산 후 DOM 주입
    injectPnlColumns(json.data.list);
    // content로도 전달 (회원 목록 추출용)
    window.postMessage({
      type: "__TAPBIT_HISTORIES__",
      data: json.data,
    }, "*");
  }
}
```

#### 9.3.2 PnL% 계산 함수

```javascript
function calcPnl(tradeData, mode = "margin") {
  const profit = parseFloat(tradeData.profit) || 0;
  const tradeFee = parseFloat(tradeData.tradeFee) || 0;
  const tradeAmount = parseFloat(tradeData.tradeAmount) || 0;
  const leverage = tradeData.leverage || 0;

  if (tradeAmount === 0 || (mode === "margin" && leverage === 0)) {
    return { pure: null, withFee: null };
  }

  const base = mode === "margin" ? (tradeAmount / leverage) : tradeAmount;
  return {
    pure: (profit / base) * 100,
    withFee: ((profit - tradeFee) / base) * 100,
  };
}
```

#### 9.3.3 테이블 DOM 주입 전략

```javascript
// Ant Design 테이블 감지 + MutationObserver
function observeTable() {
  const observer = new MutationObserver(() => {
    const table = document.querySelector(".ant-table-tbody");
    if (table && !table.dataset.pnlInjected) {
      injectColumns();
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

function injectColumns() {
  // 1. 헤더 추가
  const headerRow = document.querySelector(".ant-table-thead tr");
  if (headerRow && !headerRow.querySelector(".cs-pnl-header")) {
    appendTh(headerRow, "PnL%(순수)", "cs-pnl-header");
    appendTh(headerRow, "PnL%(수수료)", "cs-pnl-header");
  }

  // 2. 각 행에 PnL% 셀 추가
  const rows = document.querySelectorAll(".ant-table-tbody tr");
  rows.forEach((row, idx) => {
    if (row.querySelector(".cs-pnl-cell")) return;
    const trade = cachedHistories[idx];  // 캐시된 데이터
    if (!trade) return;
    const pnl = calcPnl(trade.data, currentMode);
    appendPnlTd(row, pnl.pure);
    appendPnlTd(row, pnl.withFee);
  });
}
```

#### 9.3.4 summary API 호출 (background.js)

```javascript
// FETCH_SUMMARY 핸들러
if (msg.type === "FETCH_SUMMARY") {
  const { startTime, endTime, userType } = msg;
  const stored = await chrome.storage.local.get("tapbitAuth");
  const auth = stored?.tapbitAuth?.token;
  if (!auth) {
    sendResponse({ error: "AUTH_NOT_FOUND" });
    return true;
  }

  const url = `https://agent-api.tapbit.com/agent/contract/order/history/summary`
    + `?contractType=USDT_MARGIN_CONTRACT`
    + `&userType=${userType || ""}`
    + `&startTime=${startTime}`
    + `&endTime=${endTime}`
    + `&auth=${auth}`;

  fetch(url)
    .then(r => r.json())
    .then(json => sendResponse({ data: json.data }))
    .catch(e => sendResponse({ error: e.message }));

  return true; // 비동기 응답
}
```

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 0.1 | 2026-03-09 | Initial design draft |
