# history-pnl-fee-analysis Analysis Report

> **Analysis Type**: Gap Analysis (Design vs Implementation)
>
> **Project**: Coinstep Tapbit Sync Chrome Extension
> **Version**: v1.2.0
> **Date**: 2026-03-09
> **Status**: Complete
> **Design Doc**: [history-pnl-fee-analysis.design.md](../02-design/features/history-pnl-fee-analysis.design.md)

---

## 1. Analysis Overview

### 1.1 Analysis Purpose

Compare the design document for "History PnL% & Fee Analysis" against the actual Chrome extension implementation to identify gaps, deviations, and verify feature completeness.

### 1.2 Analysis Scope

- **Design Document**: `docs/02-design/features/history-pnl-fee-analysis.design.md`
- **Implementation Files**:
  - `extensions/manifest.json`
  - `extensions/background.js`
  - `extensions/inject-tapbit.js`
  - `extensions/content-tapbit.js`
  - `extensions/content-calc.js`
- **Analysis Date**: 2026-03-09

### 1.3 Known Intentional Deviations

The design document specifies UI injection (PnL% table columns + fee analysis panel) into the **Tapbit page** (agent.tapbit.com). During implementation, all UI was moved to the **Coinstep site** (pro.coinstep.co.kr) via `content-calc.js`. This is an **approved deviation** and is scored accordingly (not penalized as a gap).

---

## 2. Overall Scores

| Category | Score | Status |
|----------|:-----:|:------:|
| Design Match | 82% | Warning |
| Architecture Compliance | 90% | OK |
| Feature Completeness | 85% | Warning |
| Error Handling | 78% | Warning |
| **Overall** | **84%** | Warning |

---

## 3. Gap Analysis (Design vs Implementation)

### 3.1 Architecture / Component Diagram

| Design Component | Design Location | Impl Location | Status | Notes |
|------------------|-----------------|---------------|--------|-------|
| inject-tapbit.js: fetch intercept (histories) | Tapbit MAIN world | inject-tapbit.js L74-86 | OK | Matches design |
| inject-tapbit.js: PnL% calculation engine | Tapbit MAIN world | content-calc.js L160-175 | Changed | Moved to Coinstep (intentional) |
| inject-tapbit.js: table DOM manipulation | Tapbit MAIN world | content-calc.js L215-449 | Changed | Moved to Coinstep (intentional) |
| inject-tapbit.js: summary fetch proxy | Tapbit MAIN world | inject-tapbit.js L94-121 | OK | Implemented as designed |
| content-tapbit.js: message relay | Tapbit content | content-tapbit.js L19-67 | OK | Matches design |
| content-tapbit.js: fee panel DOM | Tapbit content | content-calc.js L215-419 | Changed | Moved to Coinstep (intentional) |
| content-tapbit.js: summary proxy bridge | Tapbit content | content-tapbit.js L96-119 | OK | Matches design |
| background.js: auth token storage | Service worker | background.js L106-113 | OK | Matches design |
| background.js: FETCH_SUMMARY handler | Service worker | background.js L116-153 | Changed | See Section 3.5 |
| content-calc.js | Not in design | content-calc.js (entire file) | Added | New file for Coinstep UI (intentional) |

### 3.2 Data Flow Comparison

**Flow 1: PnL% Display**

| Design Step | Implementation | Status |
|-------------|---------------|--------|
| Tapbit server -> inject-tapbit.js (fetch intercept) | inject-tapbit.js L74-86 | OK |
| Response clone + parse | inject-tapbit.js L76-77 | OK |
| PnL% calculation in inject-tapbit.js | content-calc.js L160-175 (calcPnl) | Changed |
| DOM manipulation on Tapbit table (MutationObserver) | content-calc.js renders own table on Coinstep | Changed |
| Data flow: inject -> postMessage -> content-tapbit -> background -> storage -> content-calc | Implementation adds storage hop | Changed |

Design: `inject-tapbit.js` calculates PnL% and injects columns into Tapbit's Ant Design table via MutationObserver.

Implementation: `inject-tapbit.js` captures data and posts to `content-tapbit.js`, which relays to `background.js`, which saves to `chrome.storage.local`. `content-calc.js` on Coinstep listens for storage changes and renders its own complete table.

This is a significant architectural change (intentional) that adds a storage intermediary but achieves the same end result.

**Flow 2: Fee Summary**

| Design Step | Implementation | Status |
|-------------|---------------|--------|
| content-tapbit.js injects panel DOM | content-calc.js injects panel DOM on Coinstep | Changed (intentional) |
| User selects date/member, clicks search | content-calc.js L520-578 | OK |
| chrome.runtime.sendMessage FETCH_SUMMARY | content-calc.js L543-548 | OK |
| background.js calls summary API directly | background.js proxies via Tapbit tab | Changed |
| background.js returns SUMMARY_RESULT | background.js returns via sendResponse callback | Changed (minor) |
| content-tapbit.js updates panel UI | content-calc.js L567-576 updates panel UI | Changed (intentional) |

### 3.3 Data Model Comparison

| Field | Design | Implementation | Status |
|-------|--------|---------------|--------|
| TradeData.orderId | Number | Not explicitly used | OK (available in data) |
| TradeData.contractName | String | content-calc.js L439 | OK |
| TradeData.profit | String | content-calc.js L161, L433 | OK |
| TradeData.tradeFee | String | content-calc.js L162, L434 | OK |
| TradeData.tradeAmount | String | content-calc.js L163 | OK |
| TradeData.leverage | Number | content-calc.js L164 | OK |
| TradeData.direction | Number | content-calc.js L435 (side/positionSide/direction) | OK (broader matching) |
| TradeData.createTime | Number | content-calc.js L447 | OK |
| MemberData.maskId | Number | content-calc.js L228, L438 | OK |
| MemberData.remarkName | String | content-calc.js L229, L438 | OK |
| PnlResult.margin | Number | content-calc.js L170 (inline calc) | OK |
| PnlResult.pnlPctPure | Number | content-calc.js L171 (.pure) | OK |
| PnlResult.pnlPctWithFee | Number | content-calc.js L172 (.withFee) | OK |
| PnlResult.pnlPctByAmount | Number | content-calc.js L170-172 (mode switch) | OK |
| tapbitAuth storage | { token, capturedAt } | background.js L108-109 | OK |

### 3.4 Message Protocol Comparison

| Design Message | Design Direction | Implementation | Status |
|----------------|-----------------|----------------|--------|
| `__TAPBIT_HISTORIES__` | inject -> content | inject-tapbit.js L80-84 | OK |
| `__TAPBIT_AUTH__` | inject -> content | inject-tapbit.js L22-24 | OK |
| `DATA_HISTORIES` | content -> background | content-tapbit.js L52-57 | OK |
| `FETCH_SUMMARY` | content -> background | content-calc.js L543-548 | Changed: sent from content-calc (Coinstep) instead of content-tapbit |
| `SUMMARY_RESULT` | background -> content | Not used as named message | Changed: uses sendResponse callback pattern |
| `__TOGGLE_PNL_MODE__` | content -> inject | Not implemented | Missing |
| `DATA_AUTH` | content -> background | content-tapbit.js L24-27 | OK |
| `__TAPBIT_FETCH__` | Not in design | inject-tapbit.js L95 | Added |
| `__TAPBIT_FETCH_RESULT__` | Not in design | inject-tapbit.js L106-119 | Added |
| `FETCH_SUMMARY_PROXY` | Not in design | content-tapbit.js L96-119 | Added |

### 3.5 Summary API Call Method

**Design**: background.js calls the summary API **directly** via `fetch()`.

**Implementation**: background.js proxies the request through a Tapbit tab:
1. background.js sends `FETCH_SUMMARY_PROXY` to content-tapbit.js
2. content-tapbit.js posts `__TAPBIT_FETCH__` to inject-tapbit.js (MAIN world)
3. inject-tapbit.js calls `originalFetch()` (preserving cookies/Origin)
4. Result flows back: inject -> content-tapbit -> background -> content-calc

This is a significant architectural difference. The design assumed background.js could call the API directly with just the auth token. The implementation routes through the Tapbit tab to preserve cookies and Origin headers, which is likely necessary for the API to accept the request.

**Impact**: Functional improvement over design. Adds complexity but solves a real CORS/cookie issue.

---

## 4. Feature Comparison

### 4.1 Missing Features (Design exists, Implementation missing)

| # | Feature | Design Location | Description | Severity |
|---|---------|-----------------|-------------|----------|
| 1 | `__TOGGLE_PNL_MODE__` message | Design Section 4.4 | Design specifies content -> inject message for mode toggle | Low |
| 2 | MutationObserver for Ant Design table | Design Section 9.3.3 | Design uses MutationObserver to inject columns into existing table | N/A (intentional) |
| 3 | Ant Design table column injection | Design Section 5.1 | 2 extra th/td in existing Tapbit table | N/A (intentional) |
| 4 | localStorage for collapse state | Design Section 5.2 | "Collapse/expand toggle state saved in localStorage" | Low |
| 5 | Default dates from Tapbit page | Design Section 5.2 | "Default: extract from current Tapbit page startTime/endTime" | Low |
| 6 | Retry button on summary failure | Design Section 6 | "Panel shows 'query failed' + retry button" | Low |
| 7 | "No data" message for empty date range | Design Section 8.2 | Edge case handling | Low |

Notes:
- Items 2-3 are N/A because the UI location changed intentionally
- Item 1 (`__TOGGLE_PNL_MODE__`) is unnecessary since mode toggle is now handled internally in content-calc.js
- Items 4-7 are minor UX gaps

### 4.2 Added Features (Implementation exists, Design missing)

| # | Feature | Implementation Location | Description |
|---|---------|------------------------|-------------|
| 1 | content-calc.js (entire file) | extensions/content-calc.js | New content script for Coinstep (intentional) |
| 2 | Full trade history table | content-calc.js L382-400 | Complete table with 10 columns (member, pair, leverage, amount, PnL, fee, direction, PnL% pure, PnL% w/fee, time) |
| 3 | Summary proxy via Tapbit tab | background.js L132-149, content-tapbit.js L96-119 | 3-hop proxy for cookie/Origin |
| 4 | `__TAPBIT_FETCH__` / `__TAPBIT_FETCH_RESULT__` messages | inject-tapbit.js L94-121 | Generic fetch proxy in MAIN world |
| 5 | Close button (hide panel) | content-calc.js L349 | Panel can be fully hidden |
| 6 | Local fee sum calculation | content-calc.js L234-237, L504-518 | Calculates fee from cached data without API call |
| 7 | Member filter on table rows | content-calc.js L488-498 | Filters table display by member |
| 8 | Histories storage (chrome.storage.local) | background.js L92-104 | Persistent storage for cross-site data sharing |
| 9 | reqId-based request tracking | content-tapbit.js L97, inject-tapbit.js L97 | Correlation IDs for async proxy |
| 10 | 15s proxy timeout | content-tapbit.js L110-116 | Timeout for proxy requests |
| 11 | Panel starts collapsed | content-calc.js L415 | Default collapsed state |

### 4.3 Changed Features (Design differs from Implementation)

| # | Item | Design | Implementation | Impact |
|---|------|--------|---------------|--------|
| 1 | UI injection site | Tapbit (agent.tapbit.com) | Coinstep (pro.coinstep.co.kr) | High (intentional) |
| 2 | PnL% display method | Inject columns into Ant Design table | Render standalone table | Medium (intentional) |
| 3 | Summary API call | background.js direct fetch | 3-hop proxy (bg -> content-tapbit -> inject-tapbit) | Medium (functional improvement) |
| 4 | Summary result delivery | Dedicated SUMMARY_RESULT message | sendResponse callback | Low |
| 5 | Panel background color | `#0f1120` | `#0a0a14` (panel), `#0f1120` (header) | Low |
| 6 | Panel border-radius | `8px` | None (fixed full-width bar) | Low |
| 7 | Panel layout | Floating panel with rounded corners | Fixed top bar, full width | Low (different UI paradigm) |
| 8 | Date defaults | From Tapbit page URL params | Today's date | Low |
| 9 | Table columns | 7 columns (pair, direction, amount, fee, PnL, PnL% pure, PnL% w/fee) | 10 columns (adds member, leverage, time) | Low (improvement) |
| 10 | File responsibility | inject-tapbit.js owns PnL calc + DOM | content-calc.js owns PnL calc + DOM | Medium (intentional) |

---

## 5. PnL Calculation Accuracy

### 5.1 calcPnl Function Comparison

| Aspect | Design (Section 9.3.2) | Implementation (content-calc.js L160-175) | Status |
|--------|----------------------|------------------------------------------|--------|
| profit parsing | `parseFloat(tradeData.profit) \|\| 0` | `parseFloat(tradeData.profit) \|\| 0` | OK |
| tradeFee parsing | `parseFloat(tradeData.tradeFee) \|\| 0` | `parseFloat(tradeData.tradeFee) \|\| 0` | OK |
| tradeAmount parsing | `parseFloat(tradeData.tradeAmount) \|\| 0` | `parseFloat(tradeData.tradeAmount) \|\| 0` | OK |
| leverage parsing | `tradeData.leverage \|\| 0` | `tradeData.leverage \|\| 0` | OK |
| Zero guard (tradeAmount) | `tradeAmount === 0` returns null | `tradeAmount === 0` returns null | OK |
| Zero guard (leverage) | `mode === "margin" && leverage === 0` returns null | Same | OK |
| Margin base | `tradeAmount / leverage` | `tradeAmount / leverage` | OK |
| Amount base | `tradeAmount` | `tradeAmount` | OK |
| Pure PnL% | `(profit / base) * 100` | `(profit / base) * 100` | OK |
| PnL% with fee | `((profit - tradeFee) / base) * 100` | `((profit - tradeFee) / base) * 100` | OK |
| Return format | `{ pure, withFee }` | `{ pure, withFee }` | OK |

**Verdict**: PnL calculation logic is a 100% match with the design specification.

### 5.2 Display Format

| Aspect | Design | Implementation | Status |
|--------|--------|---------------|--------|
| Decimal places | 2 (e.g., +1.44%) | 2 (toFixed(2)) | OK |
| Positive prefix | Not specified | "+" sign | OK (improvement) |
| Profit color | `#34d399` (green) | `#34d399` | OK |
| Loss color | `#f87171` (red) | `#f87171` | OK |
| Null display | "---" | "---" | OK |

---

## 6. Error Handling Comparison

| Design Error Case | Design Response | Implementation | Status |
|-------------------|-----------------|---------------|--------|
| histories API parse failure | Ignore error, keep existing table | inject-tapbit.js L85: catch logs + continues | OK |
| leverage = 0 or null | Skip PnL%, show "---" | content-calc.js L166: returns { pure: null, withFee: null } | OK |
| tradeAmount = 0 | Division-by-zero prevention | content-calc.js L166: returns null | OK |
| auth token expired | "Auth expired. Refresh page" | content-calc.js L555-556: "Auth expired. Tapbit page refresh needed" | OK |
| summary API call failure | Show "query failed" + retry button | content-calc.js L558-560: shows error, no retry button | Partial |
| DOM structure change | console.warn, graceful | N/A (no Ant Design DOM manipulation) | N/A (intentional) |
| NO_TAPBIT_TAB error | Not in design | background.js L133-134: "Run sync first" | Added |
| PROXY_TIMEOUT | Not in design | content-tapbit.js L114: 15s timeout | Added |
| API_ERROR (non-200 code) | Not in design | inject-tapbit.js L111: returns error with code | Added |

---

## 7. UI Components Comparison

### 7.1 Design Section 5.2 vs Implementation

| UI Element | Design | Implementation | Status |
|------------|--------|---------------|--------|
| Panel title | "Fee Analysis" icon | "Trade History PnL% / Fee Analysis" + count badge | Changed (richer) |
| Collapse/Expand toggle | Yes, localStorage persist | Yes, but no localStorage persist | Partial |
| Member dropdown | From histories API data | content-calc.js L226-241 | OK |
| Date range (start) | HTML date input | content-calc.js L360 | OK |
| Date range (end) | HTML date input | content-calc.js L362 | OK |
| Search button | Yes | content-calc.js L363 | OK |
| Total fee display | 1 card | 2 displays: "local fee" + "API fee" | Changed (improvement) |
| Trader count display | 1 card | content-calc.js L375-376 | OK |
| Mode toggle (margin/amount) | Small text toggle above table | 2 buttons in header | Changed (better UX) |
| Default collapsed | Not specified (implies expanded) | Collapsed by default (L415) | Changed |

### 7.2 Color/Style Comparison

| CSS Variable | Design Value | Implementation Value | Status |
|-------------|-------------|---------------------|--------|
| --cs-bg-panel | #0f1120 | #0a0a14 (panel bg) | Changed (minor) |
| --cs-bg-card | #131525 | #131525 (toolbar selects) | OK |
| --cs-border | #1e293b | #1e293b | OK |
| --cs-text-primary | #e2e8f0 | #e2e8f0 | OK |
| --cs-text-secondary | #94a3b8 | #94a3b8 | OK |
| --cs-accent | #3b82f6 | #3b82f6 | OK |
| --cs-profit | #34d399 | #34d399 | OK |
| --cs-loss | #f87171 | #f87171 | OK |
| --cs-btn-bg | #1e293b | #1e293b | OK |
| --cs-btn-hover | #334155 | #334155 | OK |
| border-radius | 8px | None (full-width fixed bar) | Changed |

---

## 8. Security Compliance

| Design Requirement | Implementation | Status |
|-------------------|---------------|--------|
| Auth token in chrome.storage.local only | background.js L108-109 | OK |
| Summary API from background.js only | Proxied through Tapbit tab (still server-side context) | OK (acceptable) |
| fetch response clone only (no mutation) | inject-tapbit.js L76: `result.clone()` | OK |
| textContent for DOM injection (no innerHTML) | content-calc.js uses innerHTML with template literals | Warning |
| No external CDN/libraries | No external dependencies | OK |

**Security Note**: content-calc.js L243-401 uses `innerHTML` with template literals. The data comes from Tapbit API (trusted source) and is formatted through helper functions, so the XSS risk is low. However, the design specified `textContent` only. Values like `remarkName` could theoretically contain HTML if a malicious actor controlled member names on Tapbit.

---

## 9. Manifest Comparison

| Design Spec | Implementation | Status |
|-------------|---------------|--------|
| version: 1.2.0 | manifest.json L5: "1.2.0" | OK |
| inject-tapbit.js changes | inject-tapbit.js updated | OK |
| content-tapbit.js changes | content-tapbit.js updated | OK |
| background.js changes | background.js updated | OK |
| popup.html unchanged | Not modified | OK |
| popup.js unchanged | Not modified | OK |
| content-calc.js | Not in design file list | Added (for Coinstep UI) |
| pro.coinstep.co.kr host_permission | Not in design | manifest.json L13: added | Added |

---

## 10. Match Rate Summary

```
+-----------------------------------------------+
|  Overall Match Rate: 84%                       |
+-----------------------------------------------+
|  OK (exact match):           28 items (56%)    |
|  Changed (intentional):      12 items (24%)    |
|  Changed (unintentional):     4 items  (8%)    |
|  Added (impl only):          11 items          |
|  Missing (design only):       3 items  (6%)    |
|  Partial:                     3 items  (6%)    |
+-----------------------------------------------+

Adjusted Match Rate (excluding intentional changes): 84%
If intentional changes counted as matches: 92%
```

---

## 11. Differences Found

### 11.1 Missing Features (Design exists, Implementation missing)

| Item | Design Location | Description | Severity |
|------|-----------------|-------------|----------|
| localStorage collapse state | Section 5.2 | Panel collapse state not persisted across page loads | Low |
| Retry button on API failure | Section 6 | Error display lacks a retry button | Low |
| Default dates from Tapbit URL | Section 5.2 | Defaults to today instead of Tapbit page dates | Low |

### 11.2 Added Features (Implementation only)

| Item | Implementation Location | Description |
|------|------------------------|-------------|
| content-calc.js | New file | Full Coinstep content script (intentional) |
| 3-hop summary proxy | background.js L132-149 | Cookie/Origin-preserving API proxy |
| Local fee sum | content-calc.js L504-518 | Fee calculated from cached data |
| Close button | content-calc.js L349 | Ability to fully hide panel |
| Histories persistent storage | background.js L92-104 | Cross-site data sharing via storage |
| reqId correlation | content-tapbit.js L97 | Request tracking for async proxy |

### 11.3 Changed Features (Design != Implementation)

| Item | Design | Implementation | Impact |
|------|--------|---------------|--------|
| UI location | Tapbit page | Coinstep page | High (intentional, approved) |
| Summary API call method | Direct fetch in background | 3-hop proxy via Tapbit tab | Medium (functional improvement) |
| innerHTML usage | textContent specified | innerHTML with template literals | Medium (security consideration) |
| Panel style | Floating with border-radius | Fixed top bar, full width | Low |

---

## 12. Recommended Actions

### 12.1 Immediate (Before release)

| Priority | Item | File | Description |
|----------|------|------|-------------|
| Warning 1 | innerHTML XSS review | content-calc.js L243-401 | Sanitize `remarkName` and other user-controlled strings, or use textContent + createElement |

### 12.2 Short-term (Post-release improvement)

| Priority | Item | File | Description |
|----------|------|------|-------------|
| Low 1 | Persist collapse state | content-calc.js | Add localStorage save/restore for panel collapsed state |
| Low 2 | Add retry button | content-calc.js L560 | Add retry button when summary API fails |
| Low 3 | Empty date validation UX | content-calc.js | Show friendlier message for empty periods |

### 12.3 Design Document Updates Needed

| Item | Description |
|------|-------------|
| Update architecture diagram | Reflect Coinstep as UI host instead of Tapbit |
| Add content-calc.js to file list | Section 9.1 file modification scope |
| Document 3-hop proxy pattern | Section 2.2 data flow for summary API |
| Add `__TAPBIT_FETCH__` messages | Section 4.4 message protocol |
| Update UI mockup | Section 5.2 should show fixed top bar design |
| Add pro.coinstep.co.kr permission | Manifest changes section |
| Add histories storage flow | Data flow from background to content-calc via chrome.storage |

---

## 13. Synchronization Recommendation

Match rate is **84%** (between 70% and 90%).

> There are some differences between design and implementation. Document update is recommended.

Recommended approach: **Update design to match implementation** (Option 2).

The implementation represents an improvement over the original design in several ways:
1. UI on Coinstep is more practical (users work on Coinstep, not Tapbit admin)
2. 3-hop proxy solves real CORS/cookie issues the design did not account for
3. Full standalone table provides richer information than injected columns
4. Local fee calculation provides immediate feedback without API calls

The 3 missing features (localStorage persistence, retry button, Tapbit date defaults) are minor UX items that can be added incrementally.

---

## Version History

| Version | Date | Changes | Author |
|---------|------|---------|--------|
| 1.0 | 2026-03-09 | Initial gap analysis | Claude (gap-detector) |
